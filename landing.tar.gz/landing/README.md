# BlackGreenFox — Win98 pixel-portfolio (v3)

**v3** — Win98 естетика поширена на всю сторінку:
- **бекграунд**: класичний бірюзовий Win98-десктоп (`#008b6b → #006f55`) з тонким dither-візерунком
- **верхня панель**: справжній Win98 program title bar (синій градієнт, _ □ × кнопки)
- **кожна секція**: окреме Win98-вікно з зеленим title-bar, raised-бевелом та drop-shadow
- **Hero** ⇒ "About BlackGreenFox.exe" діалог, портрет → "PXL_PORTRAIT.BMP" — image-viewer-стиль зі сункеним фреймом і propes-row
- **6 колонок** ⇒ classic Win98 group-boxes з overlapping legend
- **CRT-монітор** ⇒ "MY_DESKTOP.scr — Display Properties" діалог
- **Footer** ⇒ Win98 status bar з 5 sunken-сегментами (Ready/links/copyright/encoding/clock)
- Win98-скролбари (`::-webkit-scrollbar` із бевелами)

Зелений акцент BlackGreenFox збережено: пікс-арт іконки, портрет, чорна діра, snake — всі лишилися зеленими; Win98-chrome навколо них це бежевий/сірий 16-кольоровий стиль.

## Файли

| Файл | Розмір | Опис |
|---|---|---|
| `index.html` | 1 KB | Точка входу, підключає React 17 + Babel standalone з CDN |
| `styles.css` | ~33 KB | Усі стилі: retro-зелений хедер/колонки + Win98 палітра, бевели, вікна, таскбар, меню |
| `app.js` | ~57 KB | Single-file React з усією логікою. Type=`text/babel` |
| `snake.html` | 2 KB | Iframe-обгортка для існуючої snake-гри (snake.wasm) |
| `snake.{js,wasm,data}` | — | Існуючі ассети snake-гри (не змінювалися) |

## Що працює (перевірено в браузері)

### Зовнішня сторінка (зелена)
- Header-status bar з uptime та "ONLINE" індикатором
- Hero: пікселевий заголовок `BLACK.GREEN.FOX`, опис, кнопки `BOOT_OS >_` / `SCROLL ↓`, інлайн SVG-портрет
- ABOUT_ME.txt — 6-колонкова сітка з рядом про себе, craft, games, graphics, science, contact
- Footer з посиланнями GITHUB / EMAIL / ↑ TOP

### Win98-стіл (всередині CRT)
- 4 ярлики: **Black Hole**, **Snake.exe**, **My Pictures**, **My Repositories**
- Двойний клік по ярлику → відкривається вікно
- Правий клік на робочому столі → контекстне меню (Refresh / Arrange Icons / Properties)
- Правий клік на ярлику → меню Open / Properties
- Таскбар: **Start**-кнопка зліва, кнопки відкритих задач, system tray зі звуком/мережею + годинник
- **Start меню**: лівий зелений banner `BlackGreenFox 98`, пункти Programs▶ / Settings▶ / Find▶ / Help / Run... / Shut Down...
- Подменю Programs → Black Hole / Snake / My Pictures / My Repositories

### Вікна (Win98 chrome)
- Класичний 3D bevel: світло top-left, тінь bottom-right
- Title bar з зеленим градієнтом (focused) / сірим (unfocused)
- Кнопки `_` (minimize) / `□` (maximize) / `✕` (close) — працюють
- Maximize заповнює весь стіл (не накриває таскбар)
- Drag по title bar (з useDraggable hook)
- Resize через handle у правому-нижньому куті
- z-index фокусу при кліку

### Black Hole — діалог Properties
- 3 вкладки: **Visualization** / **Settings** / **About**
- VISUALIZATION: канвас з custom-element `<a-hole>` + status bar (Event Horizon / Speed / Status)
- SETTINGS: групбокси `Particles` / `Discs` / `Animation` / `Colors`, всі трекбари, чекбокс Paused, color pickers, кнопки **Reset** / **OK** / **Cancel** / **Apply**
- Налаштування зберігаються в `localStorage` (`bh-settings-v1`)
- Apply → візуалізація оновлюється негайно через `setAttribute` на `<a-hole>`
- Cancel → відкат до збережених
- Reset → скидання до DEFAULT
- ABOUT: фейкова "About"-діалогова панель з версією та credits

### Snake
- Iframe на `snake.html` (існуюча WASM-гра)

### Gallery (My Pictures)
- Сітка з 8 пікселевих "файлів-картинок" (`.bmp` каптіонами)
- Клік по плитці → модальне вікно з збільшеною картинкою
- Клік по модалці або фону → закрити

### My Repositories
- GitHub API запит до `https://api.github.com/users/BlackGreenFox/repos`
- Фільтр-пошук
- Кнопка "Open profile"
- Кожне репо: іконка, ім'я, опис, мова, ⭐ зірки, ⑂ форки, дата апдейту, посилання на репо

## Як запустити локально

```bash
cd landing/
python3 -m http.server 8765
# відкрити http://localhost:8765
```

> Потрібен інтернет: React/Babel/Google-фонти/MS Sans Serif font-face (CDN 98.css fonts) тягнуться з мережі.

## Технічні деталі

- **React 17** + **Babel standalone** через unpkg.com (без build-кроку)
- **Custom element `<a-hole>`** для канвас-візуалізації (керується через `setAttribute`)
- **Pixel art** генерується inline-SVG із char-grid (функція `makePixelSvg`)
- **localStorage** для persistence налаштувань чорної діри
- **Hooks**: `useDraggable` (drag windows/titlebars/resize), `useClickOutside` (закриває меню)
- **Win98 widgets**: реалізовані через CSS-бевели (border + box-shadow inset), `--w98-*` CSS-змінні
